
trigger OrderTrigger on ECommerce_Order__c (
    before insert,
    before update
) {
    for (ECommerce_Order__c orderRecord : Trigger.new) {

        // Subtotal validation
        if (orderRecord.Subtotal__c != null &&
            orderRecord.Subtotal__c < 0) {

            orderRecord.Subtotal__c.addError(
                'Subtotal cannot be negative.'
            );
        }

        // Discount validation
        if (orderRecord.Discount__c != null &&
            orderRecord.Discount__c < 0) {

            orderRecord.Discount__c.addError(
                'Discount cannot be negative.'
            );
        }

        // Tax validation
        if (orderRecord.Tax__c != null &&
            orderRecord.Tax__c < 0) {

            orderRecord.Tax__c.addError(
                'Tax cannot be negative.'
            );
        }

        // Discount cannot exceed subtotal
        if (orderRecord.Subtotal__c != null &&
            orderRecord.Discount__c != null &&
            orderRecord.Discount__c >
                orderRecord.Subtotal__c) {

            orderRecord.Discount__c.addError(
                'Discount cannot exceed the subtotal.'
            );
        }
    }
}
