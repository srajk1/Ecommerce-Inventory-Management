
import { LightningElement, wire } from 'lwc';
import { gql, graphql } from 'lightning/uiGraphQLApi';

const PRODUCT_QUERY = gql`
    query ActiveProducts {
        uiapi {
            query {
                Product__c(
                    first: 50
                    where: { Active__c: { eq: true } }
                    orderBy: { Name: { order: ASC } }
                ) {
                    edges {
                        node {
                            Id
                            Name {
                                value
                            }
                            SKU__c {
                                value
                            }
                            Category__c {
                                value
                            }
                            Unit_Price__c {
                                value
                            }
                            Active__c {
                                value
                            }
                        }
                    }
                }
            }
        }
    }
`;

const COLUMNS = [
    { label: 'Product Name', fieldName: 'name', type: 'text' },
    { label: 'SKU', fieldName: 'sku', type: 'text' },
    { label: 'Category', fieldName: 'category', type: 'text' },
    {
        label: 'Unit Price',
        fieldName: 'unitPrice',
        type: 'currency',
        typeAttributes: {
            currencyCode: 'PKR',
            maximumFractionDigits: 2
        }
    },
    { label: 'Active', fieldName: 'active', type: 'boolean' }
];

export default class ProductCatalog extends LightningElement {
    products = [];
    columns = COLUMNS;
    loading = true;
    errorMessage;

    @wire(graphql, { query: PRODUCT_QUERY })
    wiredProducts({ data, errors }) {
        this.loading = false;

        if (errors) {
            this.products = [];
            this.errorMessage =
                'Products load nahi ho sake. Object aur field API names aur user permissions check karein.';
            return;
        }

        if (data) {
            const edges = data.uiapi.query.Product__c.edges;

            this.products = edges.map(({ node }) => ({
                id: node.Id,
                name: node.Name?.value ?? '',
                sku: node.SKU__c?.value ?? '',
                category: node.Category__c?.value ?? '',
                unitPrice: node.Unit_Price__c?.value ?? 0,
                active: node.Active__c?.value ?? false
            }));

            this.errorMessage = undefined;
        }
    }

    get hasProducts() {
        return this.products.length > 0 && !this.loading;
    }

    get showEmptyMessage() {
        return (
            !this.loading &&
            !this.errorMessage &&
            this.products.length === 0
        );
    }
}
