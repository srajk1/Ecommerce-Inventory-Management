
import { LightningElement, wire } from 'lwc';
import { getRecord, getFieldValue } from 'lightning/uiRecordApi';

const FIELDS = [
    'ECommerce_Order__c.Name',
    'ECommerce_Order__c.Order_Status__c',
    'ECommerce_Order__c.Payment_Status__c',
    'ECommerce_Order__c.Grand_Total__c',
    'ECommerce_Order__c.Shipping_Address__c'
];

export default class OrderTracker extends LightningElement {
    selectedOrderId;
    orderRecord;
    errorMessage = '';
    isLoading = false;

    handleOrderChange(event) {
        this.selectedOrderId = event.detail.recordId;
        this.orderRecord = undefined;
        this.errorMessage = '';
        this.isLoading = Boolean(this.selectedOrderId);
    }

    @wire(getRecord, {
        recordId: '$selectedOrderId',
        fields: FIELDS
    })
    wiredOrder({ data, error }) {
        if (data) {
            this.orderRecord = {
                Id: data.id,
                Name: getFieldValue(data, 'ECommerce_Order__c.Name'),
                Order_Status__c: getFieldValue(
                    data,
                    'ECommerce_Order__c.Order_Status__c'
                ),
                Payment_Status__c: getFieldValue(
                    data,
                    'ECommerce_Order__c.Payment_Status__c'
                ),
                Grand_Total__c: getFieldValue(
                    data,
                    'ECommerce_Order__c.Grand_Total__c'
                ),
                Shipping_Address__c: getFieldValue(
                    data,
                    'ECommerce_Order__c.Shipping_Address__c'
                )
            };

            this.errorMessage = '';
            this.isLoading = false;
        } else if (error) {
            this.orderRecord = undefined;
            this.errorMessage =
                error.body?.message || 'Unable to load order details.';
            this.isLoading = false;
        } else {
            this.isLoading = Boolean(this.selectedOrderId);
        }
    }
}
