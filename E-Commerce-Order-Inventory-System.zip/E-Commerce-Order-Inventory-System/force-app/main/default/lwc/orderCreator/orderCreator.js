
import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class OrderCreator extends LightningElement {

    handleSuccess(event) {
        const orderId = event.detail.id;

        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Success',
                message: 'Order created successfully. Record ID: ' + orderId,
                variant: 'success'
            })
        );

        // Clear the form after successful creation
        const form = this.template.querySelector(
            'lightning-record-edit-form'
        );

        if (form) {
            form.reset();
        }
    }

    handleError(event) {
        this.dispatchEvent(
            new ShowToastEvent({
                title: 'Order Creation Failed',
                message: event.detail.message ||
                    'Unable to create the order. Please check the fields and permissions.',
                variant: 'error',
                mode: 'sticky'
            })
        );
    }
}
