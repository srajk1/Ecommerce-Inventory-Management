
import { LightningElement, wire } from 'lwc';
import getInventory from
    '@salesforce/apex/InventoryDashboardController.getInventory';

const COLUMNS = [
    { label: 'Inventory', fieldName: 'inventoryName' },
    { label: 'Product', fieldName: 'productName' },
    { label: 'Warehouse', fieldName: 'warehouseName' },
    { label: 'On Hand', fieldName: 'quantityOnHand', type: 'number' },
    { label: 'Reserved', fieldName: 'quantityReserved', type: 'number' },
    { label: 'Available', fieldName: 'availableQuantity', type: 'number' },
    { label: 'Reorder Level', fieldName: 'reorderLevel', type: 'number' },
    { label: 'Stock Status', fieldName: 'stockStatus' }
];

export default class InventoryDashboard extends LightningElement {
    columns = COLUMNS;
    inventoryRecords = [];
    isLoading = true;
    errorMessage = '';
    showLowStockOnly = false;

    @wire(getInventory)
    wiredInventory({ data, error }) {
        this.isLoading = false;

        if (data) {
            this.inventoryRecords = data;
            this.errorMessage = '';
        } else if (error) {
            this.inventoryRecords = [];
            this.errorMessage =
                error.body?.message || 'Unable to load inventory.';
        }
    }

    get totalRecords() {
        return this.inventoryRecords.length;
    }

    get lowStockCount() {
        return this.inventoryRecords.filter(
            item => item.stockStatus === 'Low Stock'
        ).length;
    }

    get inStockCount() {
        return this.inventoryRecords.filter(
            item => item.stockStatus === 'In Stock'
        ).length;
    }

    get displayedInventory() {
        if (this.showLowStockOnly) {
            return this.inventoryRecords.filter(
                item => item.stockStatus === 'Low Stock'
            );
        }

        return this.inventoryRecords;
    }

    handleLowStockChange(event) {
        this.showLowStockOnly = event.target.checked;
    }
}
